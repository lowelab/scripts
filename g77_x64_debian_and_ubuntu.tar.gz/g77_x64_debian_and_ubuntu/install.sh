sudo dpkg -i *.deb
